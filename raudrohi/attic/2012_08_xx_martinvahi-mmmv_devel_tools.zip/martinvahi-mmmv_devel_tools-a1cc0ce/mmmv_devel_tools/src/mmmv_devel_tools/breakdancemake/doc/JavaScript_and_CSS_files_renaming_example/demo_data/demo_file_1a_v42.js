
function func_in_demo_file_1a(){
    // some smart stuff resides in here
} // func_in_demo_file_1a

