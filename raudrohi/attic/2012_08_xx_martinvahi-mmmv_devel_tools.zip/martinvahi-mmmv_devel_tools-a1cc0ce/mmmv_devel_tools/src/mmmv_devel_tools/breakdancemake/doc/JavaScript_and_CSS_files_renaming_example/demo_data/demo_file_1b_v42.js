
function func_in_demo_file_1b(){
    // some smart stuff resides in here
} // func_in_demo_file_1b

