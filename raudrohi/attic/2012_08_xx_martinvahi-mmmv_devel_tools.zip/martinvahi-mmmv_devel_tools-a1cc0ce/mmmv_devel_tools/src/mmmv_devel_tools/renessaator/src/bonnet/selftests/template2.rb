#!/usr/bin/ruby
#==========================================================================
=begin
    The sole purpose of this file is to contain test data for
    the Renessaator selftests.
=end
#==========================================================================
puts "Howdy from template 2."
# RENESSAATOR_BLOCK_START
# RENESSAATOR_SOURCE_LANGUAGE=Ruby
# RENESSAATOR_BLOCK_ID=template2_block1
#
# RENESSAATOR_SOURCE_START
# puts "# This Renessaator generated output block "
# puts "# did not exist in the template.'
# RENESSAATOR_SOURCE_END
#
# RENESSAATOR_BLOCK_END



#==========================================================================
